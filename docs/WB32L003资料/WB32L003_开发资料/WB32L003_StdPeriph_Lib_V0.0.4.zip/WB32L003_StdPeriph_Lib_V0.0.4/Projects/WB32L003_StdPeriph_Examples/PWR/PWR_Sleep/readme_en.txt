/**
  @page PWR_Sleep PWR_Sleep example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    PWR/PWR_Sleep/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the PWR PWR_Sleep example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to enters the system to SLEEP mode and wake-up from this
mode using IO interrupt.

In the associated software
  - the PC5 is configured to generate interrupt on fallingfalling edge

The system enters SLEEP mode and will wait for the  Key push-button is pressed. 
 - If the KEY button (EXTI_Line15) is the source of wakeup from SLEEP, LED1 is toggled.

This behavior is repeated in an infinite loop.

In this example, Main clock is configured at 24MHz.


@par Directory contents 

  - PWR/PWR_Sleep/PWR_Sleep.uvprojx            MDK5 project file
  - PWR/PWR_Sleep/PWR_Sleep.uvoptx             MDK5 project options file
  - PWR/PWR_Sleep/JLinkSettings.ini            Jlink settings file
  - PWR/PWR_Sleep/main.c                       Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - PC4 pin is connected to LED1
      - PC6 pin is connected to KEY1



@par How to use it ? 

In order to make the program work, you must do the following :
 - Open PWR_Sleep.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
