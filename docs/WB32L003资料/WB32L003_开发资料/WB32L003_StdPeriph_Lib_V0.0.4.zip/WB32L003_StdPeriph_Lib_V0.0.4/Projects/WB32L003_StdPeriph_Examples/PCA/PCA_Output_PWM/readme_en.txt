/**
  @page PCA_Output_PWM PCA put out PWM example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    PCA/PCA_Output_PWM/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the PCA PCA_Output_PWM example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to use PCA peripheral genetate a PWM output.

In this example, Main clock is configured at 24MHz.


@par Directory contents 

  - PCA/PCA_Output_PWM/PCA_Output_PWM.uvprojx   MDK5 project file
  - PCA/PCA_Output_PWM/PCA_Output_PWM.uvoptx    MDK5 project options file
  - PCA/PCA_Output_PWM/JLinkSettings.ini        Jlink settings file
  - PCA/PCA_Output_PWM/main.c                   Main program


@par Hardware and Software environment 

  - Hardware environment
    - Connect the PA3 to an oscilloscope to monitor the square waveforms.


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open PCA_Output_PWM.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
