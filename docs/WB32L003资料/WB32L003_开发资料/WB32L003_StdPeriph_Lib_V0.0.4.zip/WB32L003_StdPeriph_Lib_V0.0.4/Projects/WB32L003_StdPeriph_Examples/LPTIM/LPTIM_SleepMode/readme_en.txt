/**
  @page LPTIM_SleepMode LPTIM sleep mode wakeup example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    LPTIM/LPTIM_SleepMode/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the LPTIM LPTIM_SleepMode example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to use LPTIM wakeup MCU from sleep mode.

In this example, Main clock is configured at 24MHz.

The UART1 is configured as follow:
  - BaudRate: 115200
  - Word Length: 8


@par Directory contents 

  - LPTIM/LPTIM_SleepMode/LPTIM_SleepMode.uvprojx   MDK5 project file
  - LPTIM/LPTIM_SleepMode/LPTIM_SleepMode.uvoptx    MDK5 project options file
  - LPTIM/LPTIM_SleepMode/JLinkSettings.ini         Jlink settings file
  - LPTIM/LPTIM_SleepMode/main.c                    Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - UART1 (PD5, PD6) is connected to PC serial port
      - PD4 pin is connected to LED1


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open LPTIM_SleepMode.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
