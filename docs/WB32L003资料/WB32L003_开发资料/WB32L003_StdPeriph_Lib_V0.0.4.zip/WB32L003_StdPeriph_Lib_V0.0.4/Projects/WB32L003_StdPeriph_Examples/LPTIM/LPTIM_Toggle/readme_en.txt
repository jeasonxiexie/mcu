/**
  @page LPTIM_Toggle LPTIM toggle output example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    LPTIM/LPTIM_Toggle/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the LPTIM LPTIM_Toggle example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to use LPTIM toggle output function.

In this example, Main clock is configured at 24MHz.


@par Directory contents 

  - LPTIM/LPTIM_Toggle/LPTIM_Toggle.uvprojx   MDK5 project file
  - LPTIM/LPTIM_Toggle/LPTIM_Toggle.uvoptx    MDK5 project options file
  - LPTIM/LPTIM_Toggle/JLinkSettings.ini      Jlink settings file
  - LPTIM/LPTIM_Toggle/main.c                 Main program


@par Hardware and Software environment 

  - Hardware environment
    - Connect the PD2, PD3 to an oscilloscope to monitor the square waveforms.


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open LPTIM_Toggle.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
