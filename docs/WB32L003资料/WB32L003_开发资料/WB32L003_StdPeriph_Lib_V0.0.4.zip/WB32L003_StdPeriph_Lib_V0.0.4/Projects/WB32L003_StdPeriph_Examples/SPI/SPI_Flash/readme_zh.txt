/**
  @page SPI_Flash SPI_Flash example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    SPI/SPI_Flash/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the SPI SPI_Flash example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par 例程描述 

本例程提供了如何使用SPI固件库的基本示例以及与SPI FLASH通信的SPI FLASH驱动程序。

本例程系统时钟工作在24Mhz。


@par 目录内容 

  - SPI/SPI_Flash/SPI_Flash.uvprojx       MDK5工程文件
  - SPI/SPI_Flash/SPI_Flash.uvoptx        MDK5工程配置文件
  - SPI/SPI_Flash/JLinkSettings.ini       Jlink配置文件
  - SPI/SPI_Flash/main.c                  主程序
  - SPI/SPI_Flash/drv_spi_flash.c         SPI Flash驱动程序
  - SPI/SPI_Flash/drv_spi_flash.h         SPI Flash驱动程序头文件


@par 硬件和软件环境 

  - 硬件平台搭建
    - 芯片管脚和SPI FLASH连接如下：
      - SPI_NSS (PA3) 管脚连接到 SPI Flash CS (pin1)
      - SPI_SCK (PC5) 管脚连接到 SPI Flash CLK (pin6)
      - SPI_MISO (PD2) 管脚连接到 SPI Flash DO (pin2)
      - SPI_MOSI (PD3) 管脚连接到 SPI Flash DI (pin5)
      - SPI Flash WP (pin3) 连接到 Vdd
      - SPI Flash HOLD (pin7) 连接到 Vdd
      - UART1(PD5, PD6) 管脚连接到 PC 串口


@par 如何使用？ 

为了使程序工作，您必须执行以下操作 :
 - 使用 MDK5 打开此例程文件夹中的 SPI_Flash.uvprojx 工程
 - 重新编译该工程并下载到目标存储器中
 - 运行此例程
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
