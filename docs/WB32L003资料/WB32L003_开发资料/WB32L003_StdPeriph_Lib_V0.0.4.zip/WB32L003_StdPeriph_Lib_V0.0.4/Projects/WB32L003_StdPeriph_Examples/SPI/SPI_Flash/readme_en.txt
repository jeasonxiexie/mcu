/**
  @page SPI_Flash SPI_Flash example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    SPI/SPI_Flash/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the SPI SPI_Flash example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to use the SPI firmware library communicate with a SPI FLASH.

In this example, Main clock is configured at 24MHz.


@par Directory contents 

  - SPI/SPI_Flash/SPI_Flash.uvprojx       MDK5 project file
  - SPI/SPI_Flash/SPI_Flash.uvoptx        MDK5 project options file
  - SPI/SPI_Flash/JLinkSettings.ini       Jlink settings file
  - SPI/SPI_Flash/main.c                  Main program
  - SPI/SPI_Flash/drv_spi_flash.c         SPI Flash driver
  - SPI/SPI_Flash/drv_spi_flash.h         SPI Flash driver header file


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins and the SPI FLASH are connected as follows:
      - SPI_NSS (PA3) pin is connected to SPI Flash CS (pin1)
      - SPI_SCK (PC5) pin is connected to SPI Flash CLK (pin6)
      - SPI_MISO (PD2) pin is connected to SPI Flash DO (pin2)
      - SPI_MOSI (PD3) pin is connected to SPI Flash DI (pin5)
      - SPI Flash WP (pin3) is connected to Vdd
      - SPI Flash HOLD (pin7) is connected to Vdd
      - UART1 (PD5, PD6) is connected to PC serial port


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open SPI_Flash.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
