/**
  @page SPI_Master SPI_Master example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    SPI/SPI_Master/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the SPI SPI_Master example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to transmit data with SPI master.

In this example, Main clock is configured at 24MHz.


@par Directory contents 

  - SPI/SPI_Master/SPI_Master.uvprojx        MDK5 project file
  - SPI/SPI_Master/SPI_Master.uvoptx         MDK5 project options file
  - SPI/SPI_Master/JLinkSettings.ini         Jlink settings file
  - SPI/SPI_Master/main.c                    Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - PD4 pin is connected to LED1
      - PA3 pin is connected to SPI_NSS
      - PC5 pin is connected to SPI_SCK
      - PD2 pin is connected to SPI_MISO
      - PD3 pin is connected to SPI_MOSI


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open SPI_Master.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
