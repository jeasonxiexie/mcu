/**
  @page RTC_Calendar_DeepSleep_LSE RTC_Calendar_DeepSleep_LSE example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    RTC/RTC_Calendar_DeepSleep_LSE/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the RTC RTC_Calendar_DeepSleep_LSE example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to use the RTC peripheral in deep sleep mode.
As an application example, it demonstrates how to setup the RTC peripheral,entry deepsleep and generate interrupt.

In this example, Main clock is configured at 32.768KHz.


@par Directory contents 

  - RTC/RTC_Calendar_DeepSleep_LSE/RTC_Calendar_DeepSleep_LSE.uvprojx     MDK5 project file
  - RTC/RTC_Calendar_DeepSleep_LSE/RTC_Calendar_DeepSleep_LSE.uvoptx      MDK5 project options file
  - RTC/RTC_Calendar_DeepSleep_LSE/JLinkSettings.ini                      Jlink settings file
  - RTC/RTC_Calendar_DeepSleep_LSE/main.c                                 Main program
  - RTC/RTC_Calendar_DeepSleep_LSE/rtc.c                                  rtc.c file
  - RTC/RTC_Calendar_DeepSleep_LSE/rtc.h                                  rtc.h header file

@par Hardware and Software environment 

  - Hardware environment
    - UART connect to UART tool

@par How to use it ? 

In order to make the program work, you must do the following :
 - Open RTC_Calendar_DeepSleep_LSE.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
