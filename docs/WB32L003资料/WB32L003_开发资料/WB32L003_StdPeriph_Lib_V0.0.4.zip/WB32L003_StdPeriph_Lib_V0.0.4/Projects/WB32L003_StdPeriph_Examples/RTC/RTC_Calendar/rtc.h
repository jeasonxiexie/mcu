#ifndef __RTC_H
#define __RTC_H

#include "wb32l003.h"

ErrorStatus RTC_Set_Date(uint8_t year, uint8_t month, uint8_t date, uint8_t week, uint8_t cen);
ErrorStatus RTC_Set_Time(uint8_t hour, uint8_t min, uint8_t sec, uint8_t ampm); //
void RTC_Set_Alarm1(void);
uint8_t My_RTC_Init(void);
void RTC_Set_Alarm2(void);

#endif
