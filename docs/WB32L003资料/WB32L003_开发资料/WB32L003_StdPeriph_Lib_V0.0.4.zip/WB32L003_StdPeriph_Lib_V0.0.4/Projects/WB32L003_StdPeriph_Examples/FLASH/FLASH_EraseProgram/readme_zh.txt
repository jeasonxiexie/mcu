/**
  @page FLASH_EraseProgram FLASH_EraseProgram example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    FLASH/FLASH_EraseProgram/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the FLASH FLASH_EraseProgram example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par 例程描述 

本例程演示如何向芯片内部的FLASH写入数据。

本例程系统时钟工作在24Mhz。


@par 目录内容 

  - FLASH/FLASH_EraseProgram/FLASH_EraseProgram.uvprojx   MDK5工程文件
  - FLASH/FLASH_EraseProgram/FLASH_EraseProgram.uvoptx    MDK5工程配置文件
  - FLASH/FLASH_EraseProgram/JLinkSettings.ini            Jlink配置文件
  - FLASH/FLASH_EraseProgram/main.c                       主程序


@par 硬件和软件环境 

  - 硬件平台搭建
    - 芯片管脚连接如下：
      - PD4 管脚连接到 LED1
      - UART1(PD5, PD6) 管脚连接到 PC 串口


@par 如何使用？ 

为了使程序工作，您必须执行以下操作 :
 - 使用 MDK5 打开此例程文件夹中的 FLASH_EraseProgram.uvprojx 工程
 - 重新编译该工程并下载到目标存储器中
 - 运行此例程
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
