/**
  @page ADC_ExtLinesTrigger ADC external lines trigger conversion example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    ADC/ADC_ExtLinesTrigger/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the ADC ADC_ExtLinesTrigger example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to trigger ADC conversion by external line event.

In this example, Main clock is configured at 24MHz.

The UART1 is configured as follow:
  - BaudRate: 115200
  - Word Length: 8

ADC is configured to start conversion on EXTI2 event: \n
On detection of a rising edge on PA.2 pin, the conversion of ADC \n
channel_0(PC6) is done and its converted value is printed in the UART1. 


@par Directory contents 

  - ADC/ADC_ExtLinesTrigger/ADC_ExtLinesTrigger.uvprojx   MDK5 project file
  - ADC/ADC_ExtLinesTrigger/ADC_ExtLinesTrigger.uvoptx    MDK5 project options file
  - ADC/ADC_ExtLinesTrigger/JLinkSettings.ini             Jlink settings file
  - ADC/ADC_ExtLinesTrigger/main.c                        Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - UART1 (PD5, PD6) is connected to PC serial port


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open ADC_ExtLinesTrigger.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
