/**
  @page ADC_TIM1 ADC TIM1 trigger conversion example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    ADC/ADC_TIM1/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the ADC ADC_TIM1 example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par 例程描述 

本例程演示使用外部事件触发ADC采样。

本例程系统时钟工作在24Mhz。

串口1按照如下配置：
- 波特率：115200
- 数据位：8

ADC被配置为定时器1的计数溢出事件触发采样: \n
一旦检测到定时器1的计数溢出标志置位，ADC会自动触发通道0（PC6）的转换，\n
10次转换结束后，每隔1秒钟会将结果通过串口1打印出来。


@par 目录内容 

  - ADC/ADC_TIM1/ADC_TIM1.uvprojx       MDK5工程文件
  - ADC/ADC_TIM1/ADC_TIM1.uvoptx        MDK5工程配置文件
  - ADC/ADC_TIM1/JLinkSettings.ini      Jlink配置文件
  - ADC/ADC_TIM1/main.c                 主程序


@par 硬件和软件环境 

  - 硬件平台搭建
    - 芯片管脚按如下连接：
      - UART1 (PD5, PD6) 连接到串口


@par 如何使用？ 

为了使程序工作，您必须执行以下操作 :
 - 使用 MDK5 打开此例程文件夹中的 ADC_TIM1.uvprojx 工程
 - 重新编译该工程并下载到目标存储器中
 - 运行此例程
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
