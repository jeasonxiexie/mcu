/**
  @page OWIRE_Receive OWIRE_Receive example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    OWIRE/OWIRE_Receive/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the OWIRE OWIRE_Receive example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to using OWIRE to receive data.

In this example, Main clock is configured at 24MHz.


@par Directory contents 

  - OWIRE/OWIRE_Receive/OWIRE_Receive.uvprojx        MDK5 project file
  - OWIRE/OWIRE_Receive/OWIRE_Receive.uvoptx         MDK5 project options file
  - OWIRE/OWIRE_Receive/JLinkSettings.ini            Jlink settings file
  - OWIRE/OWIRE_Receive/main.c                       Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - PD4 pin is connected to LED1
      - PD2 pin is connected to OWIRE Pin


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open OWIRE_Receive.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
