/**
  @page GPIO_InputOutput GPIO_InputOutput example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    GPIO/GPIO_InputOutput/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the GPIO GPIO_InputOutput example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par 例程描述 

本例程演示如何读取GPIO输入和控制GPIO输出。

本例程系统时钟工作在24Mhz。


@par 目录内容 

  - GPIO/GPIO_InputOutput/GPIO_InputOutput.uvprojx   MDK5工程文件
  - GPIO/GPIO_InputOutput/GPIO_InputOutput.uvoptx    MDK5工程配置文件
  - GPIO/GPIO_InputOutput/JLinkSettings.ini          Jlink配置文件
  - GPIO/GPIO_InputOutput/main.c                     主程序


@par 硬件和软件环境 

  - 硬件平台搭建
    - 芯片管脚连接如下：
      - PC3 管脚连接到 LED2
      - PC4 管脚连接到 LED1
      - PC6 管脚连接到 KEY1
      - PC5 管脚连接到 KEY2


@par 如何使用？ 

为了使程序工作，您必须执行以下操作 :
 - 使用 MDK5 打开此例程文件夹中的 GPIO_InputOutput.uvprojx 工程
 - 重新编译该工程并下载到目标存储器中
 - 运行此例程
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
