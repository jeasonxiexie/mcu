/**
  @page GPIO_InputOutput GPIO_InputOutput example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    GPIO/GPIO_InputOutput/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the GPIO GPIO_InputOutput example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to read GPIO input and control GPIO output.

In this example, Main clock is configured at 24MHz.


@par Directory contents 

  - GPIO/GPIO_InputOutput/GPIO_InputOutput.uvprojx   MDK5 project file
  - GPIO/GPIO_InputOutput/GPIO_InputOutput.uvoptx    MDK5 project options file
  - GPIO/GPIO_InputOutput/JLinkSettings.ini          Jlink settings file
  - GPIO/GPIO_InputOutput/main.c                     Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - PC3 pin is connected to LED2
      - PC4 pin is connected to LED1
      - PC6 pin is connected to KEY1
      - PC5 pin is connected to KEY2


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open GPIO_InputOutput.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
