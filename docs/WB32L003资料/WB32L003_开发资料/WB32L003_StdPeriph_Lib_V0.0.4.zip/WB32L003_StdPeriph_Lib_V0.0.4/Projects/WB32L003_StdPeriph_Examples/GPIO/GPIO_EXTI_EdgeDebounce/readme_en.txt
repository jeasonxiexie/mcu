/**
  @page GPIO_EXTI_EdgeDebounce GPIO_EXTI_EdgeDebounce example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    GPIO/GPIO_EXTI_EdgeDebounce/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the GPIO GPIO_EXTI_EdgeDebounce example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to toggle the GPIO output using EXTI's edge-triggered and debounce.

In this example, Main clock is configured at 24MHz.


@par Directory contents 

  - GPIO/GPIO_EXTI_EdgeDebounce/GPIO_EXTI_EdgeDebounce.uvprojx   MDK5 project file
  - GPIO/GPIO_EXTI_EdgeDebounce/GPIO_EXTI_EdgeDebounce.uvoptx    MDK5 project options file
  - GPIO/GPIO_EXTI_EdgeDebounce/JLinkSettings.ini                Jlink settings file
  - GPIO/GPIO_EXTI_EdgeDebounce/main.c                           Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - PD4 pin is connected to LED1
      - PA3 pin is connected to KEY1


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open GPIO_EXTI_EdgeDebounce.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
