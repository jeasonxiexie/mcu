/**
  @page RCC_Config RCC_Config example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    RCC/RCC_Config/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the RCC RCC_Config example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to configure the system clock using the external 24MHz crystal oscillator, enable the external LSE clock.

In this example, Main clock is configured at 24MHz. AHB frequency division coefficient 1, APB frequency division coefficient 1.


@par Directory contents 

  - RCC/RCC_Config/RCC_Config.uvprojx      MDK5 project file
  - RCC/RCC_Config/RCC_Config.uvoptx       MDK5 project options file
  - RCC/RCC_Config/JLinkSettings.ini       Jlink settings file
  - RCC/RCC_Config/main.c                  Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - PD4 pin is connected to LED1


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open RCC_Config.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
