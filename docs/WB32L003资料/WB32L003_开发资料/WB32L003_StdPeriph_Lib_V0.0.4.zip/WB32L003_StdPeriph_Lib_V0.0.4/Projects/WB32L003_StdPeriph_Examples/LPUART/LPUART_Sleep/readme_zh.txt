/**
  @page LPUART_Sleep LPUART_Sleep example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    LPUART/LPUART_Sleep/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the LPUART LPUART_Sleep example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par 例程描述 

本例程演示LPUART在低功耗Sleep模式下如何工作。

本例程系统时钟工作在24Mhz。

LPUART在低功耗模式下由SCLK提供通信的时钟，可以正常进行数据收发，通信产生的中断可以将 \n
MCU从低功耗模式唤醒，本例程开始时会进行中断数据接收，之后进入Sleep模式，接收到外部发 \n
送的数据时唤醒MCU，打印提示信息，接收到10个字节时将收到的数据使用LPUART打印。

例程运行效果为芯片复位之后进入低功耗模式，使用上位机发送数据将芯片唤醒，之后会打印提 \n
示信息，当接收到10个数据时将收到的数据发送给上位机。

LPUART1 配置如下：
  - 波特率： 93750
  - 数据位： 8
  - 启用Sleep模式


@par 目录内容 

  - LPUART/LPUART_Sleep/LPUART_Sleep.uvprojx   MDK5工程文件
  - LPUART/LPUART_Sleep/LPUART_Sleep.uvoptx    MDK5工程配置文件
  - LPUART/LPUART_Sleep/JLinkSettings.ini      Jlink配置文件
  - LPUART/LPUART_Sleep/main.c                 主程序


@par 硬件和软件环境 

  - 硬件平台搭建
    - 芯片管脚连接如下：
      - LPUART(PC5, PD5) 连接到PC


@par 如何使用？ 

为了使程序工作，您必须执行以下操作 :
 - 使用 MDK5 打开此例程文件夹中的 LPUART_Sleep.uvprojx 工程
 - 重新编译该工程并下载到目标存储器中
 - 运行此例程
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
