/**
  @page LPUART_Sleep LPUART_Sleep example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    LPUART/LPUART_Sleep/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the LPUART LPUART_Sleep example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how LPUART works in low-power Sleep mode.

In this example, Main clock is configured at 24MHz.

In low-power mode, SCLK provides the communication clock for LPUART, so that data \n
can be sent and received normally. Communication interruption can wake MCU up from \n
low-power mode. This routine will interrupt data receiving at the beginning, then enter \n
the Sleep mode, wake up MCU when receiving external data, print prompt messages, \n
and receive 10 bytes when the received data is printed using LPUART.

The running effect of the routine is that the chip will enter the low-power mode after \n
reset, and the upper computer will send data to wake up the chip, and then the prompt \n
message will be printed. When 10 data is received, it will be displayed sends the received \n
data to the upper computer.

The LPUART is configured as follow:
  - BaudRate: 93750
  - Word Length: 8
  - Sleep mode is enabled

@par Directory contents 

  - LPUART/LPUART_Sleep/LPUART_Sleep.uvprojx   MDK5 project file
  - LPUART/LPUART_Sleep/LPUART_Sleep.uvoptx    MDK5 project options file
  - LPUART/LPUART_Sleep/JLinkSettings.ini      Jlink settings file
  - LPUART/LPUART_Sleep/main.c                 Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - LPUART (PC5, PD5) is connected to PC


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open LPUART_Sleep.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
