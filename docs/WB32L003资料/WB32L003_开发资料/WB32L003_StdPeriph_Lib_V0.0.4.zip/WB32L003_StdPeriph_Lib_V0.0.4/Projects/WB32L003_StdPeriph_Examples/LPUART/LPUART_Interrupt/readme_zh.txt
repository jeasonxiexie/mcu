/**
  @page LPUART_Interrupt LPUART_Interrupt example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    LPUART/LPUART_Interrupt/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the LPUART LPUART_Interrupt example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par 例程描述 

本例程演示如何使用LPUART的接收和发送中断。

本例程系统时钟工作在24Mhz。

本例程开始运行时会使用LPUART发送中断发出一段信息，发送完毕进入while循环中执行中断数据收发， \n
首先执行中断数据接收，接收到10个数据之后暂停LPUART接收中断，使用发送中断回发接收到的数据。 \n

LPUART 配置如下：
  - 波特率： 115200
  - 数据位： 8


@par 目录内容 

  - LPUART/LPUART_Interrupt/LPUART_Interrupt.uvprojx   MDK5工程文件
  - LPUART/LPUART_Interrupt/LPUART_Interrupt.uvoptx    MDK5工程配置文件
  - LPUART/LPUART_Interrupt/JLinkSettings.ini          Jlink配置文件
  - LPUART/LPUART_Interrupt/main.c                     主程序


@par 硬件和软件环境 

  - 硬件平台搭建
    - 芯片管脚连接如下：
      - LPUART(PC5, PC6) 管脚连接到 PC


@par 如何使用？ 

为了使程序工作，您必须执行以下操作 :
 - 使用 MDK5 打开此例程文件夹中的 LPUART_Interrupt.uvprojx 工程
 - 重新编译该工程并下载到目标存储器中
 - 运行此例程
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
