/**
  @page LPUART_Interrupt LPUART_Interrupt example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    LPUART/LPUART_Interrupt/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the LPUART LPUART_Interrupt example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to use LPUART receive and send interrupts.

In this example, Main clock is configured at 24MHz.

When this routine starts to run, it sends a message with LPUART sending interrupt. \n
After sending, it enters the while loop to send and receive interrupt data, \n
The interrupt data receive is performed first, the LPUART receive interrupt \n
is paused after 10 data has been received, and the received data is sent \n
back using the send interrupt.

The LPUART is configured as follow:
  - BaudRate: 115200
  - Word Length: 8


@par Directory contents 

  - LPUART/LPUART_Interrupt/LPUART_Interrupt.uvprojx    MDK5 project file
  - LPUART/LPUART_Interrupt/LPUART_Interrupt.uvoptx     MDK5 project options file
  - LPUART/LPUART_Interrupt/JLinkSettings.ini           Jlink settings file
  - LPUART/LPUART_Interrupt/main.c                      Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - LPUART (PC5, PC6) is connected to PC serial port


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open LPUART_Interrupt.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
