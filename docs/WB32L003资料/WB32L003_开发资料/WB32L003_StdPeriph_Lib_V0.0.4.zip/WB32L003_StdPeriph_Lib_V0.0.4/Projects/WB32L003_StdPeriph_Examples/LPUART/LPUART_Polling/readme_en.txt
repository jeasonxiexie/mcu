/**
  @page LPUART_Polling LPUART_Polling example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    LPUART/LPUART_Polling/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the LPUART LPUART_Polling example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to transmit and receive serial data by polling LPUART flag bits.

In this example, Main clock is configured at 24MHz.

This code sends a message when it starts running, and then sends all the received messages.

The LPUART1 is configured as follow:
  - BaudRate: 115200
  - Word Length: 8


@par Directory contents 

  - LPUART/LPUART_Polling/LPUART_Polling.uvprojx    MDK5 project file
  - LPUART/LPUART_Polling/LPUART_Polling.uvoptx     MDK5 project options file
  - LPUART/LPUART_Polling/JLinkSettings.ini         Jlink settings file
  - LPUART/LPUART_Polling/main.c                    Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - LPUART1 (PC5, PC6) is connected to PC serial port


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open LPUART_Polling.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
