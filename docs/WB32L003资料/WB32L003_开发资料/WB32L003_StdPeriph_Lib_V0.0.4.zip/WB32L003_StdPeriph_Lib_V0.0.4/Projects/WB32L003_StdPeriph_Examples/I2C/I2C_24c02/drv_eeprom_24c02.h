/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DRV_EEPROM_24C02_H
#define __DRV_EEPROM_24C02_H

/* Includes ------------------------------------------------------------------*/
#include "wb32l003.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions --------------------------------------------------------*/

void eeprom_24c02_init(void);
uint32_t eeprom_24c02_read(uint8_t addr, uint8_t regaddr, uint8_t* pbuf, uint32_t len);
uint32_t eeprom_24c02_write(uint8_t addr, uint8_t regaddr, const uint8_t* pdata, uint8_t len);

#endif /* __DRV_EEPROM_24C02_H */
