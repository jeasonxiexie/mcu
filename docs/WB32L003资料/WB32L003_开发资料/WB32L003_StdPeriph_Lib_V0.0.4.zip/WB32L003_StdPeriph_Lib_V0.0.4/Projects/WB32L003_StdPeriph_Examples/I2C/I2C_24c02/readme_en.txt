/**
  @page I2C_24c02 I2C eeprom 24c02 communication example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    I2C/I2C_24c02/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the I2C I2C_24c02 example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to use the I2C firmware library and an driver to communicate with an EEPROM 24C02 device.

In this example, Main clock is configured at 24MHz.

The UART1 is configured as follow:
  - BaudRate: 115200
  - Word Length: 8


@par Directory contents 

  - I2C/I2C_24c02/I2C_24c02.uvprojx   MDK5 project file
  - I2C/I2C_24c02/I2C_24c02.uvoptx    MDK5 project options file
  - I2C/I2C_24c02/JLinkSettings.ini   Jlink settings file
  - I2C/I2C_24c02/main.c              Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - UART1 (PD5, PD6) is connected to PC serial port
      - I2C (PC3, PC4) is connected to eeprom 24c02

@par How to use it ? 

In order to make the program work, you must do the following :
 - Open I2C_24c02.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
