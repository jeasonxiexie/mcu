/**
  @page AWK_DeepSleep AWK_DeepSleep example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    AWK/AWK_DeepSleep/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the AWK AWK_DeepSleep example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to use awk wakeup deepsleep mode.

In this example, Main clock is configured at 24MHz.


@par Directory contents 

  - AWK/AWK_DeepSleep/AWK_DeepSleep.uvprojx   MDK5 project file
  - AWK/AWK_DeepSleep/AWK_DeepSleep.uvoptx    MDK5 project options file
  - AWK/AWK_DeepSleep/JLinkSettings.ini       Jlink settings file
  - AWK/AWK_DeepSleep/main.c                  Main program


@par Hardware and Software environment 

  - Hardware environment
    - PC4 pin is connected to LED1


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open AWK_DeepSleep.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
