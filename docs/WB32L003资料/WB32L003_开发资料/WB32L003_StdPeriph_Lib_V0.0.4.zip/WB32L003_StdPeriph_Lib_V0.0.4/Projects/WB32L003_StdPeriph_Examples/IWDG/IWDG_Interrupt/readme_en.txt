/**
  @page IWDG_Interrupt IWDG_Interrupt example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    IWDG/IWDG_Interrupt/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the IWDG IWDG_Interrupt example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to use the IWDG's interrupt.

In this example, Main clock is configured at 24MHz.


@par Directory contents 

  - IWDG/IWDG_Interrupt/IWDG_Interrupt.uvprojx       MDK5 project file
  - IWDG/IWDG_Interrupt/IWDG_Interrupt.uvoptx        MDK5 project options file
  - IWDG/IWDG_Interrupt/JLinkSettings.ini            Jlink settings file
  - IWDG/IWDG_Interrupt/main.c                       Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - PD4 pin is connected to LED1


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open IWDG_Interrupt.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
