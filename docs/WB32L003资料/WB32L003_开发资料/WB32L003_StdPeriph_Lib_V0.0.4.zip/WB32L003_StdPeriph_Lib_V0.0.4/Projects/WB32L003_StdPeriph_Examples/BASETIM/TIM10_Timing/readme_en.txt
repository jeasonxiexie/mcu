/**
  @page TIM10_Timing TIM10_Timing example
  
  @verbatim
  ****************** (C) COPYRIGHT 2023 Westberry Technology *******************
  * @file    TIM10/TIM10_Timing/readme.txt 
  * @author  Westberry Application Team
  * @version V0.0.4
  * @date    23-April-2023
  * @brief   Description of the TIM10 TIM10_Timing example.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WESTBERRY SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example describes how to se the Timing function of TIM10.

In this example, Main clock is configured at 24MHz.

In this routine, TIM10 enables the timing function and adopts the reloading \n
counting mode. The reloading value is 65295. When the counting value reaches 65535, \n
interrupt is generated and PC4 pin is flipped, and the waveform with a flipping speed \n
of 100K is output on PC4 pin.


@par Directory contents 

  - TIM10/TIM10_Timing/TIM10_Timing.uvprojx   MDK5 project file
  - TIM10/TIM10_Timing/TIM10_Timing.uvoptx    MDK5 project options file
  - TIM10/TIM10_Timing/JLinkSettings.ini      Jlink settings file
  - TIM10/TIM10_Timing/main.c                 Main program


@par Hardware and Software environment 

  - Hardware environment
    - The chip pins are connected as follows：
      - PC4 pin is connection to oscilloscope


@par How to use it ? 

In order to make the program work, you must do the following :
 - Open TIM10_Timing.uvprojx from this example folder by Keil MDK5
 - Rebuild all files and load your image into target memory
 - Run the example 
   
 * <h3><center>&copy; COPYRIGHT 2023 Westberry Technology</center></h3>
 */
