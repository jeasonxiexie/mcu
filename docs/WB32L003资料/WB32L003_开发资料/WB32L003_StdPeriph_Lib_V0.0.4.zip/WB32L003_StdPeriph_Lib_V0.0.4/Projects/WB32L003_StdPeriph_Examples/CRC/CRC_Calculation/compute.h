/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __COMPUTE_H__
#define __COMPUTE_H__

/* Includes ------------------------------------------------------------------*/
#include "wb32l003.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
extern uint32_t result1;
extern uint32_t result2;
extern uint32_t result3;
extern uint32_t result4;

/* Exported macro ------------------------------------------------------------*/
#ifndef _countof
#define _countof(_Array) (sizeof(_Array) / sizeof(_Array[0]))
#endif

/* Exported functions --------------------------------------------------------*/

uint8_t compute(void);
uint16_t CRC16_X25_ComputeBytes(const uint8_t *ptr_data, uint32_t data_len);
uint16_t CRC16_X25_ComputeBytesContinue(const uint8_t *ptr_data, uint32_t data_len);
uint16_t CRC16_X25_ComputeHalfWords(const uint16_t *ptr_data, uint32_t data_len);
uint16_t CRC16_X25_ComputeWords(const uint32_t *ptr_data, uint32_t data_len);

#endif /* __COMPUTE_H__ */
