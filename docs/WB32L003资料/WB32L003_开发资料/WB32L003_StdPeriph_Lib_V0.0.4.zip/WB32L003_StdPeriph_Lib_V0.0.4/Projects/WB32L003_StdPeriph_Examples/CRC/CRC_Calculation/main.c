/* Includes ------------------------------------------------------------------*/
#include "wb32l003.h"
#include "compute.h"
#include "bsp_uart1.h"
#include <stdio.h>

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

int main(void)
{
  SystemCoreClockUpdate();
  uart1_init(24000000, 115200);
  printf("CRC calculate example:\r\n");
  printf("CRC polynomial is x16+x12+x5+1, Input data reverse, Output data reverse\n");

  printf("input data 0x11 0x22 0x33 0x44 0x55 0x66 0x77 0x88!\r\n");

  if (compute() == 0)
    printf("CRC calculate value == 0xF74A ,right!\r\n");
  else
    printf("CRC calculate value != 0xF74A ,wrong!\r\n");

  /* Infinite loop */
  while (1)
  {
    ;
  }
}

#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif
