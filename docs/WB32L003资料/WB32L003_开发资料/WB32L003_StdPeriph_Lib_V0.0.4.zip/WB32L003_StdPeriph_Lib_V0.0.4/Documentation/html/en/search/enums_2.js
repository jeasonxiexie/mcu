var searchData=
[
  ['i2cstatus',['I2CStatus',['../group___i2_c.html#ga9bec282875cd65e00172e875ef785bec',1,'wb32l003_i2c.h']]]
];
