var searchData=
[
  ['nvic_20functions',['NVIC Functions',['../group___c_m_s_i_s___core___n_v_i_c_functions.html',1,'']]],
  ['nested_20vectored_20interrupt_20controller_20_28nvic_29',['Nested Vectored Interrupt Controller (NVIC)',['../group___c_m_s_i_s___n_v_i_c.html',1,'']]],
  ['n',['N',['../union_a_p_s_r___type.html#abae0610bc2a97bbf7f689e953e0b451f',1,'APSR_Type::N()'],['../unionx_p_s_r___type.html#abae0610bc2a97bbf7f689e953e0b451f',1,'xPSR_Type::N()']]],
  ['negpinsel',['NegPinSel',['../struct_v_c_m_p___init_type_def.html#a6e47e8649d0120e9f0d0aec42b1b2e38',1,'VCMP_InitTypeDef']]],
  ['nfcr',['NFCR',['../struct_o_w_i_r_e___type_def.html#a4ab41082ab4032265c481db3bf7b9708',1,'OWIRE_TypeDef']]],
  ['nmi_5fhandler',['NMI_Handler',['../group___w_b32_l003___std_periph___template.html#ga6ad7a5e3ee69cb6db6a6b9111ba898bc',1,'NMI_Handler(void):&#160;wb32l003_it.c'],['../group___w_b32_l003___std_periph___template.html#ga6ad7a5e3ee69cb6db6a6b9111ba898bc',1,'NMI_Handler(void):&#160;wb32l003_it.c']]],
  ['noisefilterclk',['NoiseFilterClk',['../struct_o_w_i_r_e___init_type_def.html#a2962962b323dc65b693f2968bb43c85b',1,'OWIRE_InitTypeDef']]],
  ['noisefilteren',['NoiseFilterEn',['../struct_o_w_i_r_e___init_type_def.html#a7d5c73c6ecf8c40606ac2e564b2760f7',1,'OWIRE_InitTypeDef']]],
  ['npriv',['nPRIV',['../union_c_o_n_t_r_o_l___type.html#a2a6e513e8a6bf4e58db169e312172332',1,'CONTROL_Type']]],
  ['nvic',['NVIC',['../group___c_m_s_i_s__core__base.html#gac8e97e8ce56ae9f57da1363a937f8a17',1,'core_cm0plus.h']]],
  ['nvic_5fbase',['NVIC_BASE',['../group___c_m_s_i_s__core__base.html#gaa0288691785a5f868238e0468b39523d',1,'core_cm0plus.h']]],
  ['nvic_5fdecodepriority',['NVIC_DecodePriority',['../group___c_m_s_i_s___core___n_v_i_c_functions.html#ga3387607fd8a1a32cccd77d2ac672dd96',1,'core_cm0plus.h']]],
  ['nvic_5fencodepriority',['NVIC_EncodePriority',['../group___c_m_s_i_s___core___n_v_i_c_functions.html#gadb94ac5d892b376e4f3555ae0418ebac',1,'core_cm0plus.h']]],
  ['nvic_5ftype',['NVIC_Type',['../struct_n_v_i_c___type.html',1,'']]]
];
