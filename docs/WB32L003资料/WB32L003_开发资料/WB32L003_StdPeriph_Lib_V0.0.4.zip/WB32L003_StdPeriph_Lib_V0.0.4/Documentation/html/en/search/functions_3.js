var searchData=
[
  ['crc_5faccumulate',['CRC_Accumulate',['../group___c_r_c.html#ga6ff198db10a3e770717cf0163c5549f9',1,'CRC_Accumulate(const uint8_t *ptr_data, uint32_t bufferLength):&#160;wb32l003_crc.c'],['../group___c_r_c___private___functions.html#ga3d151daf15c4461f6393d271c02effd4',1,'CRC_Accumulate(const uint8_t *pBuffer, uint32_t bufferLength):&#160;wb32l003_crc.c']]],
  ['crc_5fcalculate',['CRC_Calculate',['../group___c_r_c.html#ga1cedad6cd284a4d5a0f7946482533508',1,'CRC_Calculate(const uint8_t *ptr_data, uint32_t bufferLength):&#160;wb32l003_crc.c'],['../group___c_r_c___private___functions.html#ga240f1764ab793b05ee632f0a844f4c6a',1,'CRC_Calculate(const uint8_t *pBuffer, uint32_t bufferLength):&#160;wb32l003_crc.c']]],
  ['crc_5fdeinit',['CRC_DeInit',['../group___c_r_c.html#ga11f30b83f52bd9eafec8c174244ae07e',1,'CRC_DeInit(void):&#160;wb32l003_crc.c'],['../group___c_r_c___private___functions.html#ga11f30b83f52bd9eafec8c174244ae07e',1,'CRC_DeInit(void):&#160;wb32l003_crc.c']]],
  ['crc_5finitresult',['CRC_InitResult',['../group___c_r_c.html#gaeb8176c3b4653c7210704b61b0ce4726',1,'CRC_InitResult(void):&#160;wb32l003_crc.c'],['../group___c_r_c___private___functions.html#gaeb8176c3b4653c7210704b61b0ce4726',1,'CRC_InitResult(void):&#160;wb32l003_crc.c']]]
];
