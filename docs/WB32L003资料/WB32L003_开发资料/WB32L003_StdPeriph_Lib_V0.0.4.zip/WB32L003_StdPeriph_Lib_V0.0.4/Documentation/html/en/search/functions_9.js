var searchData=
[
  ['nmi_5fhandler',['NMI_Handler',['../group___w_b32_l003___std_periph___template.html#ga6ad7a5e3ee69cb6db6a6b9111ba898bc',1,'NMI_Handler(void):&#160;wb32l003_it.c'],['../group___w_b32_l003___std_periph___template.html#ga6ad7a5e3ee69cb6db6a6b9111ba898bc',1,'NMI_Handler(void):&#160;wb32l003_it.c']]],
  ['nvic_5fdecodepriority',['NVIC_DecodePriority',['../group___c_m_s_i_s___core___n_v_i_c_functions.html#ga3387607fd8a1a32cccd77d2ac672dd96',1,'core_cm0plus.h']]],
  ['nvic_5fencodepriority',['NVIC_EncodePriority',['../group___c_m_s_i_s___core___n_v_i_c_functions.html#gadb94ac5d892b376e4f3555ae0418ebac',1,'core_cm0plus.h']]]
];
