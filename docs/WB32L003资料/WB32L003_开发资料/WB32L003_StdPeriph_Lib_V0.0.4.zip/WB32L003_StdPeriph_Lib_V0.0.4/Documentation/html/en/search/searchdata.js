var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvwxyz",
  1: "_abcdfgilnoprstuvwx",
  2: "cmsw",
  3: "_abcfghilnoprstuvw",
  4: "_abcdefghilmnoprstuvwyz",
  5: "bfi",
  6: "i",
  7: "_ahv",
  8: "abcdefgilmnoprstuvw",
  9: "abcdfgilmoprstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Modules",
  9: "Pages"
};

