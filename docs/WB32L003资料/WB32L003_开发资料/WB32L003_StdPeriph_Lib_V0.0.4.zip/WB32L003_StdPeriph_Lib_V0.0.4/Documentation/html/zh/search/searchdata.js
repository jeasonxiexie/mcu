var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvwxyzå",
  1: "_abcdfgilnoprstuvwx",
  2: "cmsw",
  3: "_abcfghilnoprstuvw",
  4: "_abcdefghilmnoprstuvwyz",
  5: "bfi",
  6: "i",
  7: "_ahv",
  8: "abcdefgilmnoprstuvw",
  9: "abcfgilmoprstuvwå"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "结构体",
  2: "文件",
  3: "函数",
  4: "变量",
  5: "枚举",
  6: "枚举值",
  7: "宏定义",
  8: "组",
  9: "页"
};

